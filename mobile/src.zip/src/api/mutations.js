import { gql } from '@apollo/client';

// Authentication mutations
export const REGISTER_USER = gql`
  mutation RegisterUser(
    $name: String!
    $email: String!
    $phone: String
    $password: String!
    $role: String
  ) {
    register(
      name: $name
      email: $email
      phone: $phone
      password: $password
      role: $role
    ) {
      userId
      token
      tokenExpiration
      name
      phone
      phoneIsVerified
      email
      emailIsVerified
      picture
      isNewUser
      userTypeId
      isActive
    }
  }
`;

export const LOGIN_USER = gql`
  mutation LoginUser(
    $email: String!
    $password: String!
    $type: String
    $name: String
    $notificationToken: String
    $isActive: Boolean
  ) {
    login(
      email: $email
      password: $password
      type: $type
      name: $name
      notificationToken: $notificationToken
      isActive: $isActive
    ) {
      userId
      token
      tokenExpiration
      name
      phone
      phoneIsVerified
      email
      emailIsVerified
      picture
      isNewUser
      userTypeId
      isActive
    }
  }
`;

export const SEND_OTP_EMAIL = gql`
  mutation SendOtpEmail($email: String!) {
    sendOtpToEmail(email: $email) {
      result
    }
  }
`;

export const SEND_OTP_PHONE = gql`
  mutation SendOtpPhone($phone: String!) {
    sendOtpToPhoneNumber(phone: $phone) {
      result
    }
  }
`;

export const VERIFY_OTP = gql`
  mutation VerifyOtp($otp: String!, $email: String, $phone: String) {
    verifyOtp(otp: $otp, email: $email, phone: $phone) {
      result
    }
  }
`;

// Order mutations
export const PLACE_ORDER = gql`
  mutation PlaceOrder(
    $restaurant: ID!
    $orderInput: [OrderItemInput!]!
    $paymentMethod: String!
    $address: OrderAddressInput!
    $tipping: Float!
    $taxationAmount: Float!
    $orderDate: String!
    $isPickedUp: Boolean!
    $deliveryCharges: Float!
    $instructions: String
  ) {
    placeOrder(
      restaurant: $restaurant
      orderInput: $orderInput
      paymentMethod: $paymentMethod
      address: $address
      tipping: $tipping
      taxationAmount: $taxationAmount
      orderDate: $orderDate
      isPickedUp: $isPickedUp
      deliveryCharges: $deliveryCharges
      instructions: $instructions
    ) {
      id
      _id
      orderId
      orderStatus
      orderAmount
      deliveryCharges
      taxationAmount
      tipping
      orderDate
      expectedTime
      deliveryAddress {
        deliveryAddress
        details
        label
      }
      paymentMethod
      paymentStatus
    }
  }
`;

// Review mutations
export const CREATE_REVIEW = gql`
  mutation CreateReview(
    $orderId: ID!
    $restaurantId: ID!
    $rating: Int!
    $review: String
    $images: [String]
    $foodRating: Int
    $deliveryRating: Int
    $serviceRating: Int
  ) {
    createReview(
      orderId: $orderId
      restaurantId: $restaurantId
      rating: $rating
      review: $review
      images: $images
      foodRating: $foodRating
      deliveryRating: $deliveryRating
      serviceRating: $serviceRating
    ) {
      id
      _id
      rating
      review
      images
      foodRating
      deliveryRating
      serviceRating
      isVerified
      createdAt
    }
  }
`;

// Coupon mutations
export const APPLY_COUPON = gql`
  mutation ApplyCoupon(
    $code: String!
    $orderAmount: Float!
    $restaurantId: ID!
  ) {
    applyCoupon(
      code: $code
      orderAmount: $orderAmount
      restaurantId: $restaurantId
    ) {
      id
      _id
      code
      description
      discountType
      discountValue
      discountAmount
    }
  }
`;

// User mutations
export const UPDATE_USER = gql`
  mutation UpdateUser($id: ID!, $userInput: UserInput!) {
    updateUser(id: $id, userInput: $userInput) {
      id
      _id
      name
      email
      phone
      profileImage
      phoneIsVerified
      emailIsVerified
      isOrderNotification
      isOfferNotification
    }
  }
`;