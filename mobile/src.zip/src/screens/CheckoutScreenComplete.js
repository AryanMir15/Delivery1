import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  ActivityIndicator
} from 'react-native';
import { useMutation, useQuery } from '@apollo/client';
import { useSelector } from 'react-redux';
import { PLACE_ORDER_MUTATION } from '../api/mutations';
import { GET_RESTAURANTS_QUERY } from '../api/queries';

const CheckoutScreenComplete = ({ navigation, route }) => {
  const { restaurantId, cartItems } = route.params;
  
  // Form state with validation
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [addressDetails, setAddressDetails] = useState('');
  const [addressLabel, setAddressLabel] = useState('Home');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [specialInstructions, setSpecialInstructions] = useState('');
  const [latitude, setLatitude] = useState(31.5204);
  const [longitude, setLongitude] = useState(74.3587);
  
  // Validation errors
  const [errors, setErrors] = useState({});
  
  // Get restaurant details
  const { data: restaurantData, loading: restaurantLoading } = useQuery(
    GET_RESTAURANTS_QUERY
  );
  
  const [placeOrder, { loading: orderLoading }] = useMutation(PLACE_ORDER_MUTATION);
  
  const restaurant = restaurantData?.restaurants?.find(r => r._id === restaurantId);
  
  // Calculate order totals
  const calculateTotals = () => {
    const subtotal = cartItems.reduce((sum, item) => {
      const price = item.variation?.price || 0;
      return sum + (price * item.quantity);
    }, 0);
    
    const deliveryCharges = 5.00;
    const taxRate = 0.10; // 10%
    const taxAmount = subtotal * taxRate;
    const tip = 2.00;
    const total = subtotal + deliveryCharges + taxAmount + tip;
    
    return {
      subtotal: subtotal.toFixed(2),
      deliveryCharges: deliveryCharges.toFixed(2),
      tax: taxAmount.toFixed(2),
      tip: tip.toFixed(2),
      total: total.toFixed(2),
      taxAmount,
      deliveryCharges,
      tipAmount: tip
    };
  };
  
  const totals = calculateTotals();
  
  // Validate all fields
  const validateForm = () => {
    const newErrors = {};
    
    // Delivery address validation
    if (!deliveryAddress.trim()) {
      newErrors.deliveryAddress = 'Delivery address is required';
    } else if (deliveryAddress.trim().length < 10) {
      newErrors.deliveryAddress = 'Please enter a complete address';
    }
    
    // Address details validation
    if (!addressDetails.trim()) {
      newErrors.addressDetails = 'Address details are required (e.g., Building, Floor, Apartment)';
    }
    
    // Phone number validation
    const phoneRegex = /^\+?[\d\s-]{10,}$/;
    if (!phoneNumber.trim()) {
      newErrors.phoneNumber = 'Phone number is required';
    } else if (!phoneRegex.test(phoneNumber)) {
      newErrors.phoneNumber = 'Please enter a valid phone number';
    }
    
    // Location validation
    if (!latitude || !longitude) {
      newErrors.location = 'Location coordinates are required';
    } else if (latitude < -90 || latitude > 90) {
      newErrors.location = 'Invalid latitude (must be between -90 and 90)';
    } else if (longitude < -180 || longitude > 180) {
      newErrors.location = 'Invalid longitude (must be between -180 and 180)';
    }
    
    // Cart validation
    if (!cartItems || cartItems.length === 0) {
      newErrors.cart = 'Cart is empty';
    }
    
    // Restaurant validation
    if (!restaurant) {
      newErrors.restaurant = 'Restaurant information not found';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handlePlaceOrder = async () => {
    // Validate form
    if (!validateForm()) {
      Alert.alert(
        'Validation Error',
        'Please fill in all required fields correctly',
        [{ text: 'OK' }]
      );
      return;
    }
    
    try {
      // Prepare order items with complete data
      const orderInput = cartItems.map(item => ({
        food: item.food.id,
        title: item.food.title || 'Unknown Item',
        description: item.food.description || '',
        image: item.food.image || '',
        quantity: item.quantity,
        variation: {
          title: item.variation.title,
          price: item.variation.price,
          discounted: item.variation.discounted || 0,
          addons: [],
          isOutOfStock: false
        },
        addons: [],
        specialInstructions: item.specialInstructions || ''
      }));
      
      // Prepare address with complete data
      const address = {
        deliveryAddress: deliveryAddress.trim(),
        location: [parseFloat(longitude), parseFloat(latitude)],
        details: addressDetails.trim(),
        label: addressLabel
      };
      
      // Get current date/time
      const orderDate = new Date().toISOString();
      
      console.log('📦 Placing order with data:', {
        restaurant: restaurantId,
        itemCount: orderInput.length,
        total: totals.total,
        address: address.deliveryAddress,
        orderDate
      });
      
      // Place order
      const { data } = await placeOrder({
        variables: {
          restaurant: restaurantId,
          orderInput,
          paymentMethod: 'card',
          address,
          tipping: parseFloat(totals.tipAmount),
          taxationAmount: parseFloat(totals.taxAmount),
          orderDate,
          isPickedUp: false,
          deliveryCharges: parseFloat(totals.deliveryCharges),
          instructions: specialInstructions.trim() || 'No special instructions'
        }
      });
      
      const order = data.placeOrder;
      
      console.log('✅ Order placed successfully:', {
        orderId: order.orderId,
        status: order.orderStatus,
        paidAmount: order.paidAmount
      });
      
      // Show success message
      Alert.alert(
        'Order Placed Successfully!',
        `Order #${order.orderId}\nStatus: ${order.orderStatus}\nTotal: ETB ${order.paidAmount.toFixed(2)}`,
        [
          {
            text: 'Track Order',
            onPress: () => navigation.navigate('OrderTracking', {
              orderId: order._id,
              orderNumber: order.orderId
            })
          }
        ]
      );
      
    } catch (error) {
      console.error('❌ Order placement error:', error);
      Alert.alert(
        'Order Failed',
        error.message || 'Failed to place order. Please try again.',
        [{ text: 'OK' }]
      );
    }
  };
  
  if (restaurantLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#4CAF50" />
        <Text style={styles.loadingText}>Loading restaurant details...</Text>
      </View>
    );
  }
  
  return (
    <ScrollView style={styles.container}>
      {/* Restaurant Information */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>🏪 Shop Information</Text>
        {restaurant && (
          <View style={styles.infoCard}>
            <Text style={styles.restaurantName}>{restaurant.name}</Text>
            <Text style={styles.restaurantAddress}>{restaurant.address}</Text>
            <Text style={styles.locationCoords}>
              📍 Location: [{restaurant.location.coordinates[0].toFixed(4)}, {restaurant.location.coordinates[1].toFixed(4)}]
            </Text>
          </View>
        )}
      </View>
      
      {/* Order Items */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>🛒 Order Items ({cartItems.length})</Text>
        {cartItems.map((item, index) => (
          <View key={index} style={styles.itemCard}>
            <View style={styles.itemHeader}>
              <Text style={styles.itemTitle}>{item.food.title}</Text>
              <Text style={styles.itemPrice}>
                ETB {(item.variation.price * item.quantity).toFixed(2)}
              </Text>
            </View>
            <Text style={styles.itemDetails}>
              {item.variation.title} × {item.quantity}
            </Text>
            <Text style={styles.itemPrice}>
              ETB {item.variation.price.toFixed(2)} each
            </Text>
          </View>
        ))}
      </View>
      
      {/* Delivery Address */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>🏠 Delivery Information</Text>
        
        <Text style={styles.label}>Delivery Address *</Text>
        <TextInput
          style={[styles.input, errors.deliveryAddress && styles.inputError]}
          placeholder="Enter complete delivery address"
          value={deliveryAddress}
          onChangeText={setDeliveryAddress}
          multiline
        />
        {errors.deliveryAddress && (
          <Text style={styles.errorText}>{errors.deliveryAddress}</Text>
        )}
        
        <Text style={styles.label}>Address Details *</Text>
        <TextInput
          style={[styles.input, errors.addressDetails && styles.inputError]}
          placeholder="Building, Floor, Apartment number"
          value={addressDetails}
          onChangeText={setAddressDetails}
          multiline
        />
        {errors.addressDetails && (
          <Text style={styles.errorText}>{errors.addressDetails}</Text>
        )}
        
        <Text style={styles.label}>Address Label</Text>
        <View style={styles.labelButtons}>
          {['Home', 'Work', 'Other'].map(label => (
            <TouchableOpacity
              key={label}
              style={[
                styles.labelButton,
                addressLabel === label && styles.labelButtonActive
              ]}
              onPress={() => setAddressLabel(label)}
            >
              <Text style={[
                styles.labelButtonText,
                addressLabel === label && styles.labelButtonTextActive
              ]}>
                {label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
        
        <Text style={styles.label}>Phone Number *</Text>
        <TextInput
          style={[styles.input, errors.phoneNumber && styles.inputError]}
          placeholder="+1234567890"
          value={phoneNumber}
          onChangeText={setPhoneNumber}
          keyboardType="phone-pad"
        />
        {errors.phoneNumber && (
          <Text style={styles.errorText}>{errors.phoneNumber}</Text>
        )}
        
        <Text style={styles.label}>Location Coordinates</Text>
        <View style={styles.coordsRow}>
          <View style={styles.coordInput}>
            <Text style={styles.coordLabel}>Latitude</Text>
            <TextInput
              style={styles.input}
              value={latitude.toString()}
              onChangeText={(text) => setLatitude(parseFloat(text) || 0)}
              keyboardType="numeric"
            />
          </View>
          <View style={styles.coordInput}>
            <Text style={styles.coordLabel}>Longitude</Text>
            <TextInput
              style={styles.input}
              value={longitude.toString()}
              onChangeText={(text) => setLongitude(parseFloat(text) || 0)}
              keyboardType="numeric"
            />
          </View>
        </View>
        {errors.location && (
          <Text style={styles.errorText}>{errors.location}</Text>
        )}
        
        <Text style={styles.label}>Special Instructions (Optional)</Text>
        <TextInput
          style={styles.input}
          placeholder="e.g., Please call when you arrive"
          value={specialInstructions}
          onChangeText={setSpecialInstructions}
          multiline
        />
      </View>
      
      {/* Order Summary */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>💰 Order Summary</Text>
        <View style={styles.summaryCard}>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Subtotal</Text>
            <Text style={styles.summaryValue}>ETB {totals.subtotal}</Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Delivery Charges</Text>
            <Text style={styles.summaryValue}>ETB {totals.deliveryCharges}</Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Tax (10%)</Text>
            <Text style={styles.summaryValue}>ETB {totals.tax}</Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Tip</Text>
            <Text style={styles.summaryValue}>ETB {totals.tip}</Text>
          </View>
          <View style={[styles.summaryRow, styles.totalRow]}>
            <Text style={styles.totalLabel}>Total</Text>
            <Text style={styles.totalValue}>ETB {totals.total}</Text>
          </View>
        </View>
      </View>
      
      {/* Place Order Button */}
      <TouchableOpacity
        style={[styles.placeOrderButton, orderLoading && styles.buttonDisabled]}
        onPress={handlePlaceOrder}
        disabled={orderLoading}
      >
        {orderLoading ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <Text style={styles.placeOrderText}>
            Place Order - ETB {totals.total}
          </Text>
        )}
      </TouchableOpacity>
      
      <View style={styles.bottomSpacer} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#666',
  },
  section: {
    backgroundColor: '#fff',
    marginTop: 10,
    padding: 15,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#333',
  },
  infoCard: {
    backgroundColor: '#f9f9f9',
    padding: 12,
    borderRadius: 8,
    borderLeftWidth: 4,
    borderLeftColor: '#4CAF50',
  },
  restaurantName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  restaurantAddress: {
    fontSize: 14,
    color: '#666',
    marginBottom: 5,
  },
  locationCoords: {
    fontSize: 12,
    color: '#999',
  },
  itemCard: {
    backgroundColor: '#f9f9f9',
    padding: 12,
    borderRadius: 8,
    marginBottom: 10,
  },
  itemHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 5,
  },
  itemTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    flex: 1,
  },
  itemDetails: {
    fontSize: 14,
    color: '#666',
    marginBottom: 3,
  },
  itemPrice: {
    fontSize: 14,
    fontWeight: '600',
    color: '#4CAF50',
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    marginTop: 15,
    marginBottom: 5,
  },
  input: {
    backgroundColor: '#f9f9f9',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    fontSize: 14,
    color: '#333',
  },
  inputError: {
    borderColor: '#f44336',
  },
  errorText: {
    color: '#f44336',
    fontSize: 12,
    marginTop: 5,
  },
  labelButtons: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 5,
  },
  labelButton: {
    flex: 1,
    padding: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd',
    alignItems: 'center',
  },
  labelButtonActive: {
    backgroundColor: '#4CAF50',
    borderColor: '#4CAF50',
  },
  labelButtonText: {
    fontSize: 14,
    color: '#666',
  },
  labelButtonTextActive: {
    color: '#fff',
    fontWeight: '600',
  },
  coordsRow: {
    flexDirection: 'row',
    gap: 10,
  },
  coordInput: {
    flex: 1,
  },
  coordLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 5,
  },
  summaryCard: {
    backgroundColor: '#f9f9f9',
    padding: 15,
    borderRadius: 8,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  summaryLabel: {
    fontSize: 14,
    color: '#666',
  },
  summaryValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  totalRow: {
    borderTopWidth: 1,
    borderTopColor: '#ddd',
    paddingTop: 10,
    marginTop: 5,
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  totalValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#4CAF50',
  },
  placeOrderButton: {
    backgroundColor: '#4CAF50',
    margin: 15,
    padding: 18,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonDisabled: {
    backgroundColor: '#ccc',
  },
  placeOrderText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  bottomSpacer: {
    height: 20,
  },
});

export default CheckoutScreenComplete;
