// Rider App - Socket.io Service for Sending Location
import io from 'socket.io-client';
import AsyncStorage from '@react-native-async-storage/async-storage';

const SOCKET_URL = 'http://10.80.214.227:4000'; // Backend IP address

class SocketService {
  constructor() {
    this.socket = null;
    this.connected = false;
  }

  async connect() {
    if (this.socket && this.connected) {
      console.log('✅ Rider socket already connected');
      return this.socket;
    }

    console.log('🔌 Rider connecting to socket server:', SOCKET_URL);

    // Get auth token from storage
    const token = await AsyncStorage.getItem('token');
    
    this.socket = io(SOCKET_URL, {
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionAttempts: 10,
      timeout: 10000,
      auth: {
        token: token || '',
      },
    });

    this.socket.on('connect', () => {
      console.log('✅ Rider socket connected:', this.socket.id);
      this.connected = true;
    });

    this.socket.on('disconnect', (reason) => {
      console.log('❌ Rider socket disconnected:', reason);
      this.connected = false;
    });

    this.socket.on('connect_error', (error) => {
      console.error('❌ Socket connection error:', error.message);
    });

    return this.socket;
  }

  // Send rider location to backend
  async sendLocation(data) {
    if (!this.socket) await this.connect();

    const { lat, lng, riderId, orderId } = data;
    
    if (!lat || !lng || !riderId || !orderId) {
      console.error('❌ Missing location data:', data);
      return;
    }

    this.socket.emit('rider_location', {
      lat,
      lng,
      riderId,
      orderId,
      timestamp: Date.now(),
    });

    console.log(`📍 Location sent: ${lat.toFixed(4)}, ${lng.toFixed(4)}`);
  }

  // Notify delivery started
  async startDelivery(riderId, orderId) {
    if (!this.socket) await this.connect();

    console.log(`🏍️ Starting delivery: ${orderId}`);
    this.socket.emit('rider_start_delivery', { riderId, orderId });
  }

  // Notify delivery completed
  async completeDelivery(riderId, orderId) {
    if (!this.socket) await this.connect();

    console.log(`✅ Completing delivery: ${orderId}`);
    this.socket.emit('rider_complete_delivery', { riderId, orderId });
  }

  disconnect() {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
      this.connected = false;
      console.log('🔌 Rider socket disconnected');
    }
  }

  isConnected() {
    return this.connected;
  }
}

export default new SocketService();
