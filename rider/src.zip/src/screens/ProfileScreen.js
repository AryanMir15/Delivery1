import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Switch, Alert } from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import { MaterialCommunityIcons as Icon } from '@expo/vector-icons';
import { useMutation, gql } from '@apollo/client';
import { logout, updateRider, setAvailability } from '../store/authSlice';
import socketService from '../services/socketService';
import AsyncStorage from '@react-native-async-storage/async-storage';

const UPDATE_RIDER_AVAILABILITY = gql`
  mutation UpdateUser($id: ID!, $userInput: UserInput!) {
    updateUser(id: $id, userInput: $userInput) {
      id
      name
      email
      available
    }
  }
`;

const ProfileScreen = ({ navigation }) => {
  const dispatch = useDispatch();
  const user = useSelector((state) => state.auth.user);
  const [available, setAvailable] = useState(user?.available || false);

  const [updateAvailability, { loading }] = useMutation(UPDATE_RIDER_AVAILABILITY, {
    onCompleted: (data) => {
      if (data.updateUser) {
        dispatch(setAvailability(data.updateUser.available));
        dispatch(updateRider({ available: data.updateUser.available }));
        Alert.alert(
          'Status Updated',
          `You are now ${data.updateUser.available ? 'ONLINE' : 'OFFLINE'}`,
          [{ text: 'OK' }]
        );
      }
    },
    onError: (error) => {
      Alert.alert('Error', 'Failed to update status. Please try again.');
      setAvailable(!available); // Revert toggle on error
    },
  });

  useEffect(() => {
    setAvailable(user?.available || false);
  }, [user?.available]);

  const handleToggleAvailability = (value) => {
    const newStatus = value;
    setAvailable(newStatus);
    
    // Update locally first for immediate feedback
    dispatch(setAvailability(newStatus));
    
    // Show confirmation
    Alert.alert(
      'Change Status',
      `Do you want to go ${newStatus ? 'ONLINE' : 'OFFLINE'}?`,
      [
        {
          text: 'Cancel',
          onPress: () => {
            setAvailable(!newStatus);
            dispatch(setAvailability(!newStatus));
          },
          style: 'cancel',
        },
        {
          text: 'Confirm',
          onPress: () => {
            // Update socket availability
            socketService.updateAvailability(newStatus);
            console.log(`Rider is now ${newStatus ? 'ONLINE' : 'OFFLINE'}`);
          },
        },
      ]
    );
  };

  const handleLogout = async () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Logout',
          style: 'destructive',
          onPress: async () => {
            // Disconnect socket
            socketService.disconnect();
            console.log('✅ Socket disconnected');
            
            // Clear token
            await AsyncStorage.removeItem('riderToken');
            
            // Logout
            dispatch(logout());
          },
        },
      ]
    );
  };

  const MenuItem = ({ icon, title, onPress, rightComponent }) => (
    <TouchableOpacity style={styles.menuItem} onPress={onPress}>
      <View style={styles.menuLeft}>
        <Icon name={icon} size={24} color="#2EC4B6" />
        <Text style={styles.menuTitle}>{title}</Text>
      </View>
      {rightComponent || <Icon name="chevron-right" size={24} color="#CED4DA" />}
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Profile</Text>
      </View>
      
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.profileCard}>
          <View style={styles.avatar}>
            <Icon name="account" size={50} color="#FFFFFF" />
          </View>
          <Text style={styles.name}>{user?.name || 'Rider Name'}</Text>
          <Text style={styles.email}>{user?.email || 'rider@example.com'}</Text>
          
          <View style={styles.availabilityContainer}>
            <View>
              <Text style={styles.availabilityLabel}>Available for Orders</Text>
              <Text style={[styles.statusText, { color: available ? '#2EC4B6' : '#E63946' }]}>
                {available ? 'ONLINE' : 'OFFLINE'}
              </Text>
            </View>
            <Switch
              value={available}
              onValueChange={handleToggleAvailability}
              trackColor={{ false: '#CED4DA', true: '#2EC4B6' }}
              thumbColor="#FFFFFF"
              disabled={loading}
            />
          </View>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account</Text>
          <MenuItem
            icon="account-edit"
            title="Edit Profile"
            onPress={() => {}}
          />
          <MenuItem
            icon="motorbike"
            title="Vehicle Information"
            onPress={() => {}}
          />
          <MenuItem
            icon="lock"
            title="Change Password"
            onPress={() => {}}
          />
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Settings</Text>
          <MenuItem
            icon="bell"
            title="Notifications"
            onPress={() => {}}
          />
          <MenuItem
            icon="help-circle"
            title="Help & Support"
            onPress={() => {}}
          />
          <MenuItem
            icon="information"
            title="About"
            onPress={() => {}}
          />
        </View>
        
        <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
          <Icon name="logout" size={24} color="#E63946" />
          <Text style={styles.logoutText}>Logout</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  header: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    paddingTop: 50,
    borderBottomWidth: 1,
    borderBottomColor: '#E9ECEF',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1D3557',
  },
  content: {
    padding: 15,
  },
  profileCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 30,
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#2EC4B6',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
  },
  name: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#1D3557',
    marginBottom: 5,
  },
  email: {
    fontSize: 14,
    color: '#6C757D',
    marginBottom: 20,
  },
  availabilityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
    paddingTop: 20,
    borderTopWidth: 1,
    borderTopColor: '#E9ECEF',
  },
  availabilityLabel: {
    fontSize: 16,
    color: '#495057',
    fontWeight: '500',
  },
  statusText: {
    fontSize: 14,
    fontWeight: 'bold',
    marginTop: 4,
  },
  section: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    marginBottom: 15,
    overflow: 'hidden',
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#6C757D',
    padding: 15,
    paddingBottom: 10,
    textTransform: 'uppercase',
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 15,
    borderTopWidth: 1,
    borderTopColor: '#F8F9FA',
  },
  menuLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  menuTitle: {
    fontSize: 16,
    color: '#495057',
    marginLeft: 15,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 15,
    marginTop: 10,
    marginBottom: 30,
  },
  logoutText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#E63946',
    marginLeft: 10,
  },
});

export default ProfileScreen;
